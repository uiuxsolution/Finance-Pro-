import React from 'react';
import { useCalculator } from '../context/CalculatorContext';

const AssetAllocationPie: React.FC = () => {
  const { results } = useCalculator();
  
  // Calculate percentages for the pie chart
  const total = results.totalAssets || 0;
  const categories = {
    cash: (results.cash || 0) / total * 100,
    investments: (results.investments || 0) / total * 100,
    realEstate: (results.realEstate || 0) / total * 100,
    other: (results.otherAssets || 0) / total * 100,
  };

  return (
    <div className="p-4">
      <h3 className="text-lg font-semibold mb-4">Asset Allocation</h3>
      <div className="grid grid-cols-2 gap-2">
        {Object.entries(categories).map(([category, percentage]) => (
          <div key={category} className="bg-gray-100 dark:bg-gray-800 p-2 rounded">
            <div className="flex justify-between items-center">
              <span className="capitalize">{category}</span>
              <span>{percentage.toFixed(1)}%</span>
            </div>
            <div className="w-full bg-gray-200 dark:bg-gray-700 h-2 rounded-full mt-1">
              <div
                className="bg-blue-500 h-2 rounded-full"
                style={{ width: `${percentage}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AssetAllocationPie;
