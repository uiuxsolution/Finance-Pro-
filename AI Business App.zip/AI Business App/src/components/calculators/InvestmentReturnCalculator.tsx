import React from 'react';
import { useCalculator } from '../../context/CalculatorContext';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Area,
  ComposedChart
} from 'recharts';

export default function InvestmentReturnCalculator() {
  const { inputValues, setInputValues, setResults, results } = useCalculator();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setInputValues({ ...inputValues, [name]: value });
  };

  const handleCalculate = () => {
    const initialInvestment = parseFloat(inputValues.initialInvestment || '0');
    const monthlyContribution = parseFloat(inputValues.monthlyContribution || '0');
    const years = parseFloat(inputValues.years || '0');
    const expectedReturn = parseFloat(inputValues.expectedReturn || '0') / 100;

    if (years > 0) {
      const conservative = expectedReturn * 0.5;
      const moderate = expectedReturn;
      const aggressive = expectedReturn * 1.5;

      const projections = Array.from({ length: Math.floor(years) + 1 }, (_, year) => {
        const totalInvested = initialInvestment + (monthlyContribution * 12 * year);
        
        const calculateGrowth = (rate: number) => {
          let balance = initialInvestment;
          for (let i = 0; i < year * 12; i++) {
            balance = (balance + monthlyContribution) * (1 + rate / 12);
          }
          return balance;
        };

        return {
          year,
          conservative: calculateGrowth(conservative),
          moderate: calculateGrowth(moderate),
          aggressive: calculateGrowth(aggressive),
          invested: totalInvested
        };
      });

      setResults({
        initialInvestment,
        monthlyContribution,
        years,
        expectedReturn,
        projections
      });
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Investment Parameters</h3>
          <div className="space-y-2">
            <input
              type="number"
              name="initialInvestment"
              placeholder="Initial Investment"
              value={inputValues.initialInvestment || ''}
              onChange={handleInputChange}
              className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
              min="0"
              step="1000"
            />
            <input
              type="number"
              name="monthlyContribution"
              placeholder="Monthly Contribution"
              value={inputValues.monthlyContribution || ''}
              onChange={handleInputChange}
              className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
              min="0"
              step="100"
            />
            <input
              type="number"
              name="expectedReturn"
              placeholder="Expected Annual Return (%)"
              value={inputValues.expectedReturn || ''}
              onChange={handleInputChange}
              className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
              min="0"
              max="100"
              step="0.1"
            />
            <input
              type="number"
              name="years"
              placeholder="Investment Period (Years)"
              value={inputValues.years || ''}
              onChange={handleInputChange}
              className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
              min="1"
              max="50"
              step="1"
            />
          </div>

          <button
            onClick={handleCalculate}
            className="w-full mt-6 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded transition-colors duration-200"
          >
            Calculate Returns
          </button>
        </div>

        {results && results.projections && results.projections.length > 0 && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Investment Summary</h3>
            <div className="grid grid-cols-1 gap-4">
              <div className="p-4 bg-blue-50 dark:bg-blue-900 rounded-lg">
                <p className="text-sm text-blue-600 dark:text-blue-200">Total Investment</p>
                <p className="text-2xl font-bold text-blue-700 dark:text-blue-100">
                  {formatCurrency(results.initialInvestment + (results.monthlyContribution * 12 * results.years))}
                </p>
              </div>
              <div className="p-4 bg-purple-50 dark:bg-purple-900 rounded-lg">
                <p className="text-sm text-purple-600 dark:text-purple-200">Expected Return Rate</p>
                <p className="text-2xl font-bold text-purple-700 dark:text-purple-100">
                  {results.expectedReturn.toFixed(1)}%
                </p>
              </div>
              <div className="p-4 bg-green-50 dark:bg-green-900 rounded-lg">
                <p className="text-sm text-green-600 dark:text-green-200">Final Balance (Moderate)</p>
                <p className="text-2xl font-bold text-green-700 dark:text-green-100">
                  {formatCurrency(results.projections[results.projections.length - 1].moderate)}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {results?.projections && results.projections.length > 0 && (
        <div className="mt-8">
          <h3 className="text-lg font-semibold mb-4">Growth Projections</h3>
          <div className="h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart
                data={results.projections}
                margin={{
                  top: 5,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis
                  dataKey="year"
                  label={{ value: 'Years', position: 'insideBottom', offset: -5 }}
                />
                <YAxis
                  tickFormatter={(value) => formatCurrency(value)}
                  label={{
                    value: 'Amount',
                    angle: -90,
                    position: 'insideLeft',
                    offset: 10,
                  }}
                />
                <Tooltip
                  formatter={(value: number) => [formatCurrency(value), '']}
                  labelFormatter={(label) => `Year ${label}`}
                />
                <Legend />
                <Area
                  type="monotone"
                  dataKey="invested"
                  name="Total Invested"
                  fill="#d1d5db"
                  stroke="#9ca3af"
                  fillOpacity={0.3}
                />
                <Line
                  type="monotone"
                  dataKey="conservative"
                  name="Conservative"
                  stroke="#10b981"
                  strokeWidth={2}
                />
                <Line
                  type="monotone"
                  dataKey="moderate"
                  name="Moderate"
                  stroke="#3b82f6"
                  strokeWidth={2}
                />
                <Line
                  type="monotone"
                  dataKey="aggressive"
                  name="Aggressive"
                  stroke="#8b5cf6"
                  strokeWidth={2}
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </div>
  );
}
