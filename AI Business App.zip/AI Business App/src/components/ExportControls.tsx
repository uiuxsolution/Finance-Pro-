import React from 'react';
import { useCalculator } from '../context/CalculatorContext';

export default function ExportControls() {
  const { results } = useCalculator();

  const handleExport = () => {
    try {
      const dataStr = JSON.stringify(results, null, 2);
      const dataUri = `data:application/json;charset=utf-8,${encodeURIComponent(dataStr)}`;
      
      const linkElement = document.createElement('a');
      linkElement.setAttribute('href', dataUri);
      linkElement.setAttribute('download', 'calculator-results.json');
      linkElement.click();
    } catch (error) {
      console.error('Failed to export results:', error);
    }
  };

  return (
    <button
      onClick={handleExport}
      className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition-colors duration-200"
    >
      Export Results
    </button>
  );
}
