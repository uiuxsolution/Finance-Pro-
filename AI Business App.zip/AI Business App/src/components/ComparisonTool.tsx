import { Tabs, Table } from '@radix-ui/themes';

export default function ComparisonTool({ scenarios }) {
  return (
    <Tabs.Root defaultValue="scenario1">
      <Tabs.List>
        <Tabs.Trigger value="scenario1">15-Year Fixed</Tabs.Trigger>
        <Tabs.Trigger value="scenario2">30-Year Fixed</Tabs.Trigger>
        <Tabs.Trigger value="scenario3">Your Scenario</Tabs.Trigger>
      </Tabs.List>

      {scenarios?.map((scenario) => (
        <Tabs.Content key={scenario.id} value={scenario.id}>
          <Table.Root>
            <Table.Header>
              <Table.Row>
                <Table.ColumnHeaderCell>Metric</Table.ColumnHeaderCell>
                <Table.ColumnHeaderCell>Value</Table.ColumnHeaderCell>
              </Table.Row>
            </Table.Header>
            <Table.Body>
              <Table.Row>
                <Table.Cell>Monthly Payment</Table.Cell>
                <Table.Cell>{scenario.monthlyPayment}</Table.Cell>
              </Table.Row>
              {/* Additional comparison metrics */}
            </Table.Body>
          </Table.Root>
        </Tabs.Content>
      ))}
    </Tabs.Root>
  );
}
