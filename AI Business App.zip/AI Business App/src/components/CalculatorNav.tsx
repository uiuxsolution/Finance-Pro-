import { CalculatorType, CalculatorConfig } from '../types';
import { calculatorConfigs } from '../config';

interface CalculatorNavProps {
  activeCalculator: CalculatorType;
  setActiveCalculator: (type: CalculatorType) => void;
}

export default function CalculatorNav({ activeCalculator, setActiveCalculator }: CalculatorNavProps) {
  return (
    <nav className="space-y-1">
      {calculatorConfigs.map((item) => (
        <button
          key={item.id}
          onClick={() => setActiveCalculator(item.id)}
          className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-md ${
            activeCalculator === item.id
              ? 'bg-blue-50 text-blue-700 hover:bg-blue-50'
              : 'text-gray-900 hover:bg-gray-50'
          }`}
        >
          <span className="truncate">{item.title}</span>
        </button>
      ))}
    </nav>
  );
}
