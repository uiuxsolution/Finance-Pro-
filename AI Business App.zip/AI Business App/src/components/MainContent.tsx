import React from 'react';
import { useCalculator } from '../context/CalculatorContext';
import Sidebar from './Sidebar';
import MortgageCalculator from './calculators/MortgageCalculator';
import LoanRepaymentCalculator from './calculators/LoanRepaymentCalculator';
import SavingsGrowthCalculator from './calculators/SavingsGrowthCalculator';
import InvestmentReturnCalculator from './calculators/InvestmentReturnCalculator';
import RetirementPlanner from './calculators/RetirementPlanner';

export default function MainContent() {
  const { activeCalculator } = useCalculator();

  const renderCalculator = () => {
    switch (activeCalculator) {
      case 'mortgage':
        return <MortgageCalculator />;
      case 'loan':
        return <LoanRepaymentCalculator />;
      case 'savings':
        return <SavingsGrowthCalculator />;
      case 'investment':
        return <InvestmentReturnCalculator />;
      case 'retirement':
        return <RetirementPlanner />;
      default:
        return <MortgageCalculator />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100">
      <div className="flex h-screen">
        <Sidebar />
        <main className="flex-1 overflow-auto">
          <div className="p-8">
            <header className="mb-8">
              <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">
                {activeCalculator === 'mortgage' && 'Mortgage Calculator'}
                {activeCalculator === 'loan' && 'Loan Repayment Calculator'}
                {activeCalculator === 'savings' && 'Savings Growth Calculator'}
                {activeCalculator === 'investment' && 'Investment Return Calculator'}
                {activeCalculator === 'retirement' && 'Retirement Planner'}
              </h1>
              <p className="mt-2 text-gray-600 dark:text-gray-400">
                {activeCalculator === 'mortgage' && 'Calculate your monthly mortgage payments and view amortization schedule'}
                {activeCalculator === 'loan' && 'Plan your loan repayments and understand total costs'}
                {activeCalculator === 'savings' && 'Track your savings growth with compound interest'}
                {activeCalculator === 'investment' && 'Project your investment returns with different risk levels'}
                {activeCalculator === 'retirement' && 'Plan for a comfortable retirement with detailed projections'}
              </p>
            </header>
            {renderCalculator()}
          </div>
        </main>
      </div>
    </div>
  );
}
