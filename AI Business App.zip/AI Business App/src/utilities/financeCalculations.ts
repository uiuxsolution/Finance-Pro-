export const calculateLoanRepayment = (
  principal: number,
  annualRate: number,
  years: number,
  additionalFees: number = 0
) => {
  const monthlyRate = annualRate / 100 / 12;
  const payments = years * 12;
  let schedule = [];
  
  if (monthlyRate === 0) {
    const monthlyPayment = (principal + additionalFees) / payments;
    return {
      monthlyPayment,
      totalInterest: 0,
      totalPayment: principal + additionalFees,
      schedule: Array.from({ length: payments }, (_, i) => ({
        month: i + 1,
        payment: monthlyPayment,
        principal: monthlyPayment,
        interest: 0,
        remainingBalance: principal - monthlyPayment * (i + 1)
      }))
    };
  }

  const monthlyPayment =
    (principal * monthlyRate * Math.pow(1 + monthlyRate, payments)) /
    (Math.pow(1 + monthlyRate, payments) - 1);

  let balance = principal;
  for (let month = 1; month <= payments; month++) {
    const interestPayment = balance * monthlyRate;
    const principalPayment = monthlyPayment - interestPayment;
    balance -= principalPayment;

    schedule.push({
      month,
      payment: monthlyPayment,
      principal: principalPayment,
      interest: interestPayment,
      remainingBalance: Math.max(balance, 0)
    });
  }

  return {
    monthlyPayment: monthlyPayment + (additionalFees / payments),
    totalInterest: monthlyPayment * payments - principal,
    totalPayment: monthlyPayment * payments + additionalFees,
    schedule
  };
};

export const calculateCompoundInterest = (
  initialAmount: number,
  monthlyContribution: number,
  annualRate: number,
  years: number
) => {
  const monthlyRate = annualRate / 100 / 12;
  const months = years * 12;
  let balance = initialAmount;
  const schedule = [];

  for (let month = 1; month <= months; month++) {
    const interestEarned = balance * monthlyRate;
    balance += interestEarned + monthlyContribution;
    
    schedule.push({
      month,
      balance,
      interestEarned,
      totalContributions: initialAmount + monthlyContribution * month
    });
  }

  return {
    futureValue: balance,
    earnedInterest: balance - (initialAmount + monthlyContribution * months),
    schedule
  };
};

export const calculateInvestmentReturns = (
  initial: number,
  monthly: number,
  years: number,
  expectedReturn: number,
  volatility: number
) => {
  // Monte Carlo simulation implementation
  return {
    optimistic: { /*...*/ },
    average: { /*...*/ },
    pessimistic: { /*...*/ }
  };
};

export const calculateMortgagePayment = ({
  price,
  downPayment,
  interestRate,
  years,
  propertyTax,
  insurance,
  pmiRate
}) => {
  const loanAmount = price - downPayment;
  const monthlyRate = interestRate / 100 / 12;
  const payments = years * 12;
  
  // Calculate base P&I payment
  const monthlyPI = (loanAmount * monthlyRate * Math.pow(1 + monthlyRate, payments)) /
    (Math.pow(1 + monthlyRate, payments) - 1);

  // Calculate additional costs
  const monthlyTax = propertyTax / 12;
  const monthlyInsurance = insurance / 12;
  const monthlyPMI = downPayment < price * 0.2 ? (loanAmount * pmiRate) / 12 : 0;

  // Generate amortization schedule
  let balance = loanAmount;
  const schedule = [];
  
  for (let month = 1; month <= payments; month++) {
    const interest = balance * monthlyRate;
    const principal = monthlyPI - interest;
    balance -= principal;

    schedule.push({
      month,
      principal,
      interest,
      pmi: monthlyPMI,
      tax: monthlyTax,
      insurance: monthlyInsurance,
      totalPayment: monthlyPI + monthlyPMI + monthlyTax + monthlyInsurance
    });
  }

  return {
    principalAndInterest: monthlyPI,
    totalMonthlyPayment: monthlyPI + monthlyPMI + monthlyTax + monthlyInsurance,
    totalCost: (monthlyPI + monthlyPMI) * payments + (propertyTax + insurance) * years,
    schedule,
    scenarios: generateComparisonScenarios({ price, downPayment, interestRate, years })
  };
};

export const calculateRetirementProjections = ({
  currentAge,
  retirementAge,
  currentIncome,
  contributionPercent,
  employerMatch,
  expectedReturns,
  currentSavings,
  taxRateNow,
  taxRateRetirement
}) => {
  const yearsToRetirement = retirementAge - currentAge;
  const annualReturn = expectedReturns / 100;
  
  // Traditional 401(k) calculations
  let traditionalBalance = currentSavings;
  let rothBalance = currentSavings;
  const contributionLimit = 22500; // 2023 IRS limit
  
  const projection = Array.from({ length: yearsToRetirement }, (_, i) => {
    const year = i + 1;
    const income = currentIncome * Math.pow(1.03, i); // 3% annual raise
    
    // Traditional contributions (pre-tax)
    const employeeTraditional = Math.min(
      income * (contributionPercent / 100),
      contributionLimit
    );
    const employerTraditional = income * (employerMatch / 100);
    const traditionalContribution = employeeTraditional + employerTraditional;
    traditionalBalance = (traditionalBalance + traditionalContribution) * (1 + annualReturn);
    
    // Roth contributions (post-tax)
    const employeeRoth = Math.min(
      income * (contributionPercent / 100) * (1 - taxRateNow / 100),
      contributionLimit
    );
    const employerRoth = income * (employerMatch / 100);
    const rothContribution = employeeRoth + employerRoth;
    rothBalance = (rothBalance + rothContribution) * (1 + annualReturn);

    return {
      year,
      age: currentAge + year,
      traditional: traditionalBalance,
      roth: rothBalance,
      income
    };
  });

  // Calculate tax implications
  const traditionalWithTax = projection[projection.length-1].traditional * (1 - taxRateRetirement/100);
  const rothWithTax = projection[projection.length-1].roth;

  return {
    projection,
    traditional: traditionalWithTax,
    roth: rothWithTax,
    advantage: rothWithTax - traditionalWithTax,
    advantageType: rothWithTax > traditionalWithTax ? 'Roth' : 'Traditional'
  };
};

export const calculateNetWorth = ({ assets, liabilities }) => {
  const totalAssets = Object.values(assets).reduce((sum, val) => sum + val, 0);
  const totalLiabilities = Object.values(liabilities).reduce((sum, val) => sum + val, 0);
  const netWorth = totalAssets - totalLiabilities;
  
  return {
    totalAssets,
    totalLiabilities,
    netWorth,
    assetAllocation: Object.entries(assets).map(([category, value]) => ({
      category,
      value,
      percentage: (value / totalAssets) * 100
    })),
    debtBreakdown: Object.entries(liabilities).map(([category, value]) => ({
      category,
      value,
      percentage: (value / totalLiabilities) * 100
    })),
    history: [] // Implement historical tracking logic
  };
};
