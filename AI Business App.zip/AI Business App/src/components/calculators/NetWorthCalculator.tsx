import React from 'react';
import { useCalculator } from '../../context/CalculatorContext';
import NetWorthChart from '../NetWorthChart';
import AssetAllocationPie from '../AssetAllocationPie';

export default function NetWorthCalculator() {
  const { inputValues, setInputValues, setResults } = useCalculator();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    const numValue = value ? parseFloat(value) : 0;
    setInputValues({ ...inputValues, [name]: value });

    // Calculate totals
    const newInputs = { ...inputValues, [name]: value };
    const assets = {
      cash: parseFloat(newInputs.cash) || 0,
      investments: parseFloat(newInputs.investments) || 0,
      realEstate: parseFloat(newInputs.realEstate) || 0,
      otherAssets: parseFloat(newInputs.otherAssets) || 0
    };

    const liabilities = {
      mortgage: parseFloat(newInputs.mortgage) || 0,
      loans: parseFloat(newInputs.loans) || 0,
      creditCards: parseFloat(newInputs.creditCards) || 0,
      otherLiabilities: parseFloat(newInputs.otherLiabilities) || 0
    };

    const totalAssets = Object.values(assets).reduce((a, b) => a + b, 0);
    const totalLiabilities = Object.values(liabilities).reduce((a, b) => a + b, 0);

    setResults({
      ...assets,
      ...liabilities,
      totalAssets,
      totalLiabilities,
      netWorth: totalAssets - totalLiabilities
    });
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Assets</h3>
          <div className="space-y-2">
            <input
              type="number"
              name="cash"
              placeholder="Cash and Savings"
              value={inputValues.cash || ''}
              onChange={handleInputChange}
              className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
            />
            <input
              type="number"
              name="investments"
              placeholder="Investments"
              value={inputValues.investments || ''}
              onChange={handleInputChange}
              className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
            />
            <input
              type="number"
              name="realEstate"
              placeholder="Real Estate"
              value={inputValues.realEstate || ''}
              onChange={handleInputChange}
              className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
            />
            <input
              type="number"
              name="otherAssets"
              placeholder="Other Assets"
              value={inputValues.otherAssets || ''}
              onChange={handleInputChange}
              className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
            />
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Liabilities</h3>
          <div className="space-y-2">
            <input
              type="number"
              name="mortgage"
              placeholder="Mortgage"
              value={inputValues.mortgage || ''}
              onChange={handleInputChange}
              className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
            />
            <input
              type="number"
              name="loans"
              placeholder="Loans"
              value={inputValues.loans || ''}
              onChange={handleInputChange}
              className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
            />
            <input
              type="number"
              name="creditCards"
              placeholder="Credit Cards"
              value={inputValues.creditCards || ''}
              onChange={handleInputChange}
              className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
            />
            <input
              type="number"
              name="otherLiabilities"
              placeholder="Other Liabilities"
              value={inputValues.otherLiabilities || ''}
              onChange={handleInputChange}
              className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
            />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <NetWorthChart />
        <AssetAllocationPie />
      </div>
    </div>
  );
}
