import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';

interface TaxComparisonProps {
  data: {
    age: number;
    traditionalTax: number;
    rothTax: number;
  }[];
}

const TaxComparison: React.FC<TaxComparisonProps> = ({ data }) => {
  const formatCurrency = (value: number) => 
    new Intl.NumberFormat('en-US', { 
      style: 'currency', 
      currency: 'USD',
      maximumFractionDigits: 0 
    }).format(value);

  return (
    <div className="w-full h-[400px] bg-white dark:bg-gray-800 rounded-lg shadow p-4">
      <h3 className="text-lg font-semibold mb-4">Tax Impact Comparison</h3>
      <ResponsiveContainer width="100%" height={320}>
        <BarChart
          data={data}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis 
            dataKey="age"
            label={{ value: 'Age', position: 'insideBottom', offset: -5 }}
          />
          <YAxis
            tickFormatter={(value) => `${formatCurrency(value)}`}
            label={{ 
              value: 'Tax Amount', 
              angle: -90, 
              position: 'insideLeft',
              offset: 10
            }}
          />
          <Tooltip
            formatter={(value: number) => [formatCurrency(value), '']}
            labelFormatter={(age) => `Age ${age}`}
          />
          <Legend />
          <Bar
            dataKey="traditionalTax"
            name="Traditional IRA Tax"
            fill="#3b82f6"
            radius={[4, 4, 0, 0]}
          />
          <Bar
            dataKey="rothTax"
            name="Roth IRA Tax"
            fill="#10b981"
            radius={[4, 4, 0, 0]}
          />
        </BarChart>
      </ResponsiveContainer>

      <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-3 bg-blue-50 dark:bg-blue-900 rounded">
          <h4 className="text-sm font-medium text-blue-700 dark:text-blue-200">Traditional IRA</h4>
          <p className="text-xs text-blue-600 dark:text-blue-300 mt-1">
            Tax-deferred contributions, taxed on withdrawal
          </p>
        </div>
        <div className="p-3 bg-green-50 dark:bg-green-900 rounded">
          <h4 className="text-sm font-medium text-green-700 dark:text-green-200">Roth IRA</h4>
          <p className="text-xs text-green-600 dark:text-green-300 mt-1">
            After-tax contributions, tax-free withdrawals
          </p>
        </div>
      </div>
    </div>
  );
};

export default TaxComparison;
