import React from 'react';
import { useCalculator } from '../../context/CalculatorContext';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';

export default function MortgageCalculator() {
  const { inputValues, setInputValues, setResults, results } = useCalculator();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setInputValues({ ...inputValues, [name]: value });
  };

  const handleCalculate = () => {
    const homePrice = parseFloat(inputValues.homePrice || '0');
    const downPayment = parseFloat(inputValues.downPayment || '0');
    const interestRate = parseFloat(inputValues.interestRate || '0') / 100;
    const loanTerm = parseFloat(inputValues.loanTerm || '0') * 12; // Convert years to months
    const propertyTax = parseFloat(inputValues.propertyTax || '0') / 100;
    const homeInsurance = parseFloat(inputValues.homeInsurance || '0');

    if (homePrice > 0 && downPayment >= 0 && interestRate > 0 && loanTerm > 0) {
      const loanAmount = homePrice - downPayment;
      const monthlyRate = interestRate / 12;
      const monthlyMortgage = calculateMonthlyPayment(loanAmount, monthlyRate, loanTerm);
      const monthlyTax = (homePrice * propertyTax) / 12;
      const monthlyInsurance = homeInsurance / 12;
      const totalMonthly = monthlyMortgage + monthlyTax + monthlyInsurance;

      const schedule = generateAmortizationSchedule(loanAmount, monthlyRate, loanTerm, monthlyMortgage);

      setResults({
        loanAmount,
        monthlyMortgage,
        monthlyTax,
        monthlyInsurance,
        totalMonthly,
        schedule,
        pieData: [
          { name: 'Principal & Interest', value: monthlyMortgage },
          { name: 'Property Tax', value: monthlyTax },
          { name: 'Home Insurance', value: monthlyInsurance }
        ]
      });
    }
  };

  const calculateMonthlyPayment = (principal: number, monthlyRate: number, months: number): number => {
    return (principal * monthlyRate * Math.pow(1 + monthlyRate, months)) / (Math.pow(1 + monthlyRate, months) - 1);
  };

  const generateAmortizationSchedule = (
    principal: number,
    monthlyRate: number,
    months: number,
    monthlyPayment: number
  ) => {
    let balance = principal;
    let totalInterest = 0;
    const yearlyData = [];

    for (let year = 0; year <= months / 12; year++) {
      const yearStart = year * 12;
      const monthsThisYear = Math.min(12, months - yearStart);
      let yearlyPrincipal = 0;
      let yearlyInterest = 0;

      for (let i = 0; i < monthsThisYear; i++) {
        const interestPayment = balance * monthlyRate;
        const principalPayment = monthlyPayment - interestPayment;
        
        yearlyPrincipal += principalPayment;
        yearlyInterest += interestPayment;
        balance -= principalPayment;
      }

      totalInterest += yearlyInterest;

      yearlyData.push({
        year,
        principalPaid: yearlyPrincipal,
        interestPaid: yearlyInterest,
        balance: Math.max(0, balance),
        totalInterest
      });
    }

    return yearlyData;
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  const COLORS = ['#3b82f6', '#8b5cf6', '#10b981'];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Property Details</h3>
          <div className="space-y-2">
            <input
              type="number"
              name="homePrice"
              placeholder="Home Price"
              value={inputValues.homePrice || ''}
              onChange={handleInputChange}
              className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
              min="0"
              step="1000"
            />
            <input
              type="number"
              name="downPayment"
              placeholder="Down Payment"
              value={inputValues.downPayment || ''}
              onChange={handleInputChange}
              className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
              min="0"
              step="1000"
            />
            <input
              type="number"
              name="interestRate"
              placeholder="Annual Interest Rate (%)"
              value={inputValues.interestRate || ''}
              onChange={handleInputChange}
              className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
              min="0"
              max="100"
              step="0.1"
            />
            <input
              type="number"
              name="loanTerm"
              placeholder="Loan Term (Years)"
              value={inputValues.loanTerm || ''}
              onChange={handleInputChange}
              className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
              min="1"
              max="50"
              step="1"
            />
          </div>

          <h3 className="text-lg font-semibold mt-6">Additional Costs</h3>
          <div className="space-y-2">
            <input
              type="number"
              name="propertyTax"
              placeholder="Annual Property Tax Rate (%)"
              value={inputValues.propertyTax || ''}
              onChange={handleInputChange}
              className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
              min="0"
              max="100"
              step="0.01"
            />
            <input
              type="number"
              name="homeInsurance"
              placeholder="Annual Home Insurance"
              value={inputValues.homeInsurance || ''}
              onChange={handleInputChange}
              className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
              min="0"
              step="100"
            />
          </div>

          <button
            onClick={handleCalculate}
            className="w-full mt-6 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded transition-colors duration-200"
          >
            Calculate Mortgage
          </button>
        </div>

        {results && results.loanAmount && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Monthly Payment Breakdown</h3>
            <div className="grid grid-cols-1 gap-4">
              <div className="p-4 bg-blue-50 dark:bg-blue-900 rounded-lg">
                <p className="text-sm text-blue-600 dark:text-blue-200">Total Monthly Payment</p>
                <p className="text-2xl font-bold text-blue-700 dark:text-blue-100">
                  {formatCurrency(results.totalMonthly)}
                </p>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-4 bg-indigo-50 dark:bg-indigo-900 rounded-lg">
                  <p className="text-sm text-indigo-600 dark:text-indigo-200">Principal & Interest</p>
                  <p className="text-xl font-bold text-indigo-700 dark:text-indigo-100">
                    {formatCurrency(results.monthlyMortgage)}
                  </p>
                </div>
                <div className="p-4 bg-purple-50 dark:bg-purple-900 rounded-lg">
                  <p className="text-sm text-purple-600 dark:text-purple-200">Property Tax</p>
                  <p className="text-xl font-bold text-purple-700 dark:text-purple-100">
                    {formatCurrency(results.monthlyTax)}
                  </p>
                </div>
                <div className="p-4 bg-green-50 dark:bg-green-900 rounded-lg">
                  <p className="text-sm text-green-600 dark:text-green-200">Insurance</p>
                  <p className="text-xl font-bold text-green-700 dark:text-green-100">
                    {formatCurrency(results.monthlyInsurance)}
                  </p>
                </div>
              </div>

              <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={results.pieData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${name}: ${formatCurrency(value)}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {results.pieData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value: number) => formatCurrency(value)} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}
      </div>

      {results?.schedule && results.schedule.length > 0 && (
        <div className="mt-8">
          <h3 className="text-lg font-semibold mb-4">Amortization Schedule</h3>
          <div className="h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={results.schedule}
                margin={{
                  top: 5,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis
                  dataKey="year"
                  label={{ value: 'Years', position: 'insideBottom', offset: -5 }}
                />
                <YAxis
                  tickFormatter={(value) => formatCurrency(value)}
                  label={{
                    value: 'Amount',
                    angle: -90,
                    position: 'insideLeft',
                    offset: 10,
                  }}
                />
                <Tooltip
                  formatter={(value: number) => [formatCurrency(value), '']}
                  labelFormatter={(label) => `Year ${label}`}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="balance"
                  name="Remaining Balance"
                  stroke="#e11d48"
                  strokeWidth={2}
                />
                <Line
                  type="monotone"
                  dataKey="principalPaid"
                  name="Principal Paid"
                  stroke="#3b82f6"
                  strokeWidth={2}
                />
                <Line
                  type="monotone"
                  dataKey="interestPaid"
                  name="Interest Paid"
                  stroke="#8b5cf6"
                  strokeWidth={2}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </div>
  );
}
